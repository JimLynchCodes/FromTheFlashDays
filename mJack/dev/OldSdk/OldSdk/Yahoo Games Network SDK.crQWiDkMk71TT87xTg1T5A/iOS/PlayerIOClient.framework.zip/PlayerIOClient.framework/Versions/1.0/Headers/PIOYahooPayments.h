//
//  YahooPayments.h
//  PlayerIOClient
//
//  Created by Arash Rassouli on 2/6/14.
//  Copyright (c) 2014 PlayerScale. All rights reserved.
//

@class PIOError;

@interface PIOYahooPayments : NSObject

/*
- (void)showBuyCoinsDialogWithCoinAmount:(int)coinAmount purchaseArguments:(NSMutableDictionary*)purchaseArguments successBlock:(void(^)(NSDictionary*))successBlock;

- (void)showBuyCoinsDialogWithCoinAmount:(int)coinAmount purchaseArguments:(NSMutableDictionary*)purchaseArguments successBlock:(void(^)(NSDictionary*))successBlock errorBlock:(void(^)(PIOError*))errorBlock;


- (void)showBuyItemsDialogWithItems:(NSArray*)items purchaseArguments:(NSMutableDictionary*)purchaseArguments successBlock:(void(^)(NSDictionary*))successBlock;

- (void)showBuyItemsDialogWithItems:(NSArray*)items purchaseArguments:(NSMutableDictionary*)purchaseArguments successBlock:(void(^)(NSDictionary*))successBlock errorBlock:(void(^)(PIOError*))errorBlock;
*/

@end
